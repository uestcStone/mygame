DateBarUI = class("DateBarUI",GameUI)

function DateBarUI:init()
	
end
